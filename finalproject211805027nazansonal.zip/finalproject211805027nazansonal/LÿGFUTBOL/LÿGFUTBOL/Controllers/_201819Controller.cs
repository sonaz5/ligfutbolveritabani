﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using LİGFUTBOL.Models;

namespace LİGFUTBOL.Controllers
{
    public class _201819Controller : Controller
    {
        private readonly FutbolContext _context;

        public _201819Controller(FutbolContext context)
        {
            _context = context;
        }

        // GET: _201819
        public async Task<IActionResult> Index()
        {
            return View(await _context._201819s.ToListAsync());
        }

        // GET: _201819/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var _201819 = await _context._201819s
                .FirstOrDefaultAsync(m => m.TakimAdi == id);
            if (_201819 == null)
            {
                return NotFound();
            }

            return View(_201819);
        }

        // GET: _201819/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: _201819/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("TakimAdi,OynadigiMacSayisi,GalibiyetSayisi,BeraberlikSayisi,MaglubiyetSayisi,AttigiGolSayisi,YedigiGolSayisi,Averaj,Puan")] _201819 _201819)
        {
            if (ModelState.IsValid)
            {
                _context.Add(_201819);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(_201819);
        }

        // GET: _201819/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var _201819 = await _context._201819s.FindAsync(id);
            if (_201819 == null)
            {
                return NotFound();
            }
            return View(_201819);
        }

        // POST: _201819/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("TakimAdi,OynadigiMacSayisi,GalibiyetSayisi,BeraberlikSayisi,MaglubiyetSayisi,AttigiGolSayisi,YedigiGolSayisi,Averaj,Puan")] _201819 _201819)
        {
            if (id != _201819.TakimAdi)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(_201819);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_201819Exists(_201819.TakimAdi))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(_201819);
        }

        // GET: _201819/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var _201819 = await _context._201819s
                .FirstOrDefaultAsync(m => m.TakimAdi == id);
            if (_201819 == null)
            {
                return NotFound();
            }

            return View(_201819);
        }

        // POST: _201819/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var _201819 = await _context._201819s.FindAsync(id);
            if (_201819 != null)
            {
                _context._201819s.Remove(_201819);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool _201819Exists(string id)
        {
            return _context._201819s.Any(e => e.TakimAdi == id);
        }
    }
}
