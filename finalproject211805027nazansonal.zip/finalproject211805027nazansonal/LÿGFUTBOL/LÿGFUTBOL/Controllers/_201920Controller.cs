﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using LİGFUTBOL.Models;

namespace LİGFUTBOL.Controllers
{
    public class _201920Controller : Controller
    {
        private readonly FutbolContext _context;

        public _201920Controller(FutbolContext context)
        {
            _context = context;
        }

        // GET: _201920
        public async Task<IActionResult> Index()
        {
            return View(await _context._201920s.ToListAsync());
        }

        // GET: _201920/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var _201920 = await _context._201920s
                .FirstOrDefaultAsync(m => m.TakimAdi == id);
            if (_201920 == null)
            {
                return NotFound();
            }

            return View(_201920);
        }

        // GET: _201920/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: _201920/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("TakimAdi,OynadigiMacSayisi,GalibiyetSayisi,BeraberlikSayisi,MaglubiyetSayisi,AttigiGolSayisi,YedigiGolSayisi,Averaj,Puan")] _201920 _201920)
        {
            if (ModelState.IsValid)
            {
                _context.Add(_201920);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(_201920);
        }

        // GET: _201920/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var _201920 = await _context._201920s.FindAsync(id);
            if (_201920 == null)
            {
                return NotFound();
            }
            return View(_201920);
        }

        // POST: _201920/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("TakimAdi,OynadigiMacSayisi,GalibiyetSayisi,BeraberlikSayisi,MaglubiyetSayisi,AttigiGolSayisi,YedigiGolSayisi,Averaj,Puan")] _201920 _201920)
        {
            if (id != _201920.TakimAdi)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(_201920);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_201920Exists(_201920.TakimAdi))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(_201920);
        }

        // GET: _201920/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var _201920 = await _context._201920s
                .FirstOrDefaultAsync(m => m.TakimAdi == id);
            if (_201920 == null)
            {
                return NotFound();
            }

            return View(_201920);
        }

        // POST: _201920/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var _201920 = await _context._201920s.FindAsync(id);
            if (_201920 != null)
            {
                _context._201920s.Remove(_201920);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool _201920Exists(string id)
        {
            return _context._201920s.Any(e => e.TakimAdi == id);
        }
    }
}
