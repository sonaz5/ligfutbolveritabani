﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using LİGFUTBOL.Models;

namespace LİGFUTBOL.Controllers
{
    public class _202021Controller : Controller
    {
        private readonly FutbolContext _context;

        public _202021Controller(FutbolContext context)
        {
            _context = context;
        }

        // GET: _202021
        public async Task<IActionResult> Index()
        {
            return View(await _context._202021s.ToListAsync());
        }

        // GET: _202021/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var _202021 = await _context._202021s
                .FirstOrDefaultAsync(m => m.TakimAdi == id);
            if (_202021 == null)
            {
                return NotFound();
            }

            return View(_202021);
        }

        // GET: _202021/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: _202021/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("TakimAdi,OynadigiMacSayisi,GalibiyetSayisi,BeraberlikSayisi,MaglubiyetSayisi,AttigiGolSayisi,YedigiGolSayisi,Averaj,Puan")] _202021 _202021)
        {
            if (ModelState.IsValid)
            {
                _context.Add(_202021);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(_202021);
        }

        // GET: _202021/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var _202021 = await _context._202021s.FindAsync(id);
            if (_202021 == null)
            {
                return NotFound();
            }
            return View(_202021);
        }

        // POST: _202021/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("TakimAdi,OynadigiMacSayisi,GalibiyetSayisi,BeraberlikSayisi,MaglubiyetSayisi,AttigiGolSayisi,YedigiGolSayisi,Averaj,Puan")] _202021 _202021)
        {
            if (id != _202021.TakimAdi)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(_202021);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_202021Exists(_202021.TakimAdi))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(_202021);
        }

        // GET: _202021/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var _202021 = await _context._202021s
                .FirstOrDefaultAsync(m => m.TakimAdi == id);
            if (_202021 == null)
            {
                return NotFound();
            }

            return View(_202021);
        }

        // POST: _202021/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var _202021 = await _context._202021s.FindAsync(id);
            if (_202021 != null)
            {
                _context._202021s.Remove(_202021);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool _202021Exists(string id)
        {
            return _context._202021s.Any(e => e.TakimAdi == id);
        }
    }
}
