﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using LİGFUTBOL.Models;

namespace LİGFUTBOL.Controllers
{
    public class _201718Controller : Controller
    {
        private readonly FutbolContext _context;

        public _201718Controller(FutbolContext context)
        {
            _context = context;
        }

        // GET: _201718
        public async Task<IActionResult> Index()
        {
            return View(await _context._201718s.ToListAsync());
        }

        // GET: _201718/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var _201718 = await _context._201718s
                .FirstOrDefaultAsync(m => m.TakimAdi == id);
            if (_201718 == null)
            {
                return NotFound();
            }

            return View(_201718);
        }

        // GET: _201718/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: _201718/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("TakimAdi,OynadigiMacSayisi,GalibiyetSayisi,BeraberlikSayisi,MaglubiyetSayisi,AttigiGolSayisi,YedigiGolSayisi,Averaj,Puan")] _201718 _201718)
        {
            if (ModelState.IsValid)
            {
                _context.Add(_201718);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(_201718);
        }

        // GET: _201718/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var _201718 = await _context._201718s.FindAsync(id);
            if (_201718 == null)
            {
                return NotFound();
            }
            return View(_201718);
        }

        // POST: _201718/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("TakimAdi,OynadigiMacSayisi,GalibiyetSayisi,BeraberlikSayisi,MaglubiyetSayisi,AttigiGolSayisi,YedigiGolSayisi,Averaj,Puan")] _201718 _201718)
        {
            if (id != _201718.TakimAdi)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(_201718);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_201718Exists(_201718.TakimAdi))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(_201718);
        }

        // GET: _201718/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var _201718 = await _context._201718s
                .FirstOrDefaultAsync(m => m.TakimAdi == id);
            if (_201718 == null)
            {
                return NotFound();
            }

            return View(_201718);
        }

        // POST: _201718/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var _201718 = await _context._201718s.FindAsync(id);
            if (_201718 != null)
            {
                _context._201718s.Remove(_201718);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool _201718Exists(string id)
        {
            return _context._201718s.Any(e => e.TakimAdi == id);
        }
    }
}
