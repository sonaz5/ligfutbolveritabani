﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using LİGFUTBOL.Models;

namespace LİGFUTBOL.Controllers
{
    public class _201617Controller : Controller
    {
        private readonly FutbolContext _context;

        public _201617Controller(FutbolContext context)
        {
            _context = context;
        }

        // GET: _201617
        public async Task<IActionResult> Index()
        {
            return View(await _context._201617s.ToListAsync());
           
        }

        // GET: _201617/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var _201617 = await _context._201617s
                .FirstOrDefaultAsync(m => m.TakimAdi == id);
            if (_201617 == null)
            {
                return NotFound();
            }

            return View(_201617);
        }

        // GET: _201617/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: _201617/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("TakimAdi,OynadigiMacSayisi,GalibiyetSayisi,BeraberlikSayisi,MaglubiyetSayisi,AttigiGolSayisi,YedigiGolSayisi,Averaj,Puan")] _201617 _201617)
        {
            if (ModelState.IsValid)
            {
                _context.Add(_201617);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(_201617);
        }

        // GET: _201617/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var _201617 = await _context._201617s.FindAsync(id);
            if (_201617 == null)
            {
                return NotFound();
            }
            return View(_201617);
        }

        // POST: _201617/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("TakimAdi,OynadigiMacSayisi,GalibiyetSayisi,BeraberlikSayisi,MaglubiyetSayisi,AttigiGolSayisi,YedigiGolSayisi,Averaj,Puan")] _201617 _201617)
        {
            if (id != _201617.TakimAdi)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(_201617);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_201617Exists(_201617.TakimAdi))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(_201617);
        }

        // GET: _201617/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var _201617 = await _context._201617s
                .FirstOrDefaultAsync(m => m.TakimAdi == id);
            if (_201617 == null)
            {
                return NotFound();
            }

            return View(_201617);
        }

        // POST: _201617/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var _201617 = await _context._201617s.FindAsync(id);
            if (_201617 != null)
            {
                _context._201617s.Remove(_201617);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool _201617Exists(string id)
        {
            return _context._201617s.Any(e => e.TakimAdi == id);
        }
    }
}
