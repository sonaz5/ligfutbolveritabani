﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace LİGFUTBOL.Models;

public partial class FutbolContext : DbContext
{
    public FutbolContext()
    {
    }

    public FutbolContext(DbContextOptions<FutbolContext> options)
        : base(options)
    {
    }

    public virtual DbSet<_201617> _201617s { get; set; }

    public virtual DbSet<_201718> _201718s { get; set; }

    public virtual DbSet<_201819> _201819s { get; set; }

    public virtual DbSet<_201920> _201920s { get; set; }

    public virtual DbSet<_202021> _202021s { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=.\\SQLEXPRESS03;Initial Catalog=futbol; Trusted_Connection=True; Integrated Security=True; TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<_201617>(entity =>
        {
            entity.HasKey(e => e.TakimAdi);

            entity.ToTable("2016_17");

            entity.Property(e => e.TakimAdi)
                .HasMaxLength(50)
                .HasColumnName("Takim_adi");
            entity.Property(e => e.AttigiGolSayisi).HasColumnName("Attigi_gol_sayisi");
            entity.Property(e => e.BeraberlikSayisi).HasColumnName("Beraberlik_sayisi");
            entity.Property(e => e.GalibiyetSayisi).HasColumnName("Galibiyet_sayisi");
            entity.Property(e => e.MaglubiyetSayisi).HasColumnName("Maglubiyet_sayisi");
            entity.Property(e => e.OynadigiMacSayisi).HasColumnName("Oynadigi_mac_sayisi");
            entity.Property(e => e.YedigiGolSayisi).HasColumnName("Yedigi_gol_sayisi");
        });

        modelBuilder.Entity<_201718>(entity =>
        {
            entity.HasKey(e => e.TakimAdi);

            entity.ToTable("2017_18");

            entity.Property(e => e.TakimAdi)
                .HasMaxLength(50)
                .HasColumnName("Takim_adi");
            entity.Property(e => e.AttigiGolSayisi).HasColumnName("Attigi_gol_sayisi");
            entity.Property(e => e.BeraberlikSayisi).HasColumnName("Beraberlik_sayisi");
            entity.Property(e => e.GalibiyetSayisi).HasColumnName("Galibiyet_sayisi");
            entity.Property(e => e.MaglubiyetSayisi).HasColumnName("Maglubiyet_sayisi");
            entity.Property(e => e.OynadigiMacSayisi).HasColumnName("Oynadigi_mac_sayisi");
            entity.Property(e => e.YedigiGolSayisi).HasColumnName("Yedigi_gol_sayisi");
        });

        modelBuilder.Entity<_201819>(entity =>
        {
            entity.HasKey(e => e.TakimAdi);

            entity.ToTable("2018_19");

            entity.Property(e => e.TakimAdi)
                .HasMaxLength(50)
                .HasColumnName("Takim_adi");
            entity.Property(e => e.AttigiGolSayisi).HasColumnName("Attigi_gol_sayisi");
            entity.Property(e => e.BeraberlikSayisi).HasColumnName("Beraberlik_sayisi");
            entity.Property(e => e.GalibiyetSayisi).HasColumnName("Galibiyet_sayisi");
            entity.Property(e => e.MaglubiyetSayisi).HasColumnName("Maglubiyet_sayisi");
            entity.Property(e => e.OynadigiMacSayisi).HasColumnName("Oynadigi_mac_sayisi");
            entity.Property(e => e.YedigiGolSayisi).HasColumnName("Yedigi_gol_sayisi");
        });

        modelBuilder.Entity<_201920>(entity =>
        {
            entity.HasKey(e => e.TakimAdi);

            entity.ToTable("2019_20");

            entity.Property(e => e.TakimAdi)
                .HasMaxLength(50)
                .HasColumnName("Takim_adi");
            entity.Property(e => e.AttigiGolSayisi).HasColumnName("Attigi_gol_sayisi");
            entity.Property(e => e.BeraberlikSayisi).HasColumnName("Beraberlik_sayisi");
            entity.Property(e => e.GalibiyetSayisi).HasColumnName("Galibiyet_sayisi");
            entity.Property(e => e.MaglubiyetSayisi).HasColumnName("Maglubiyet_sayisi");
            entity.Property(e => e.OynadigiMacSayisi).HasColumnName("Oynadigi_mac_sayisi");
            entity.Property(e => e.YedigiGolSayisi).HasColumnName("Yedigi_gol_sayisi");
        });

        modelBuilder.Entity<_202021>(entity =>
        {
            entity.HasKey(e => e.TakimAdi);

            entity.ToTable("2020_21");

            entity.Property(e => e.TakimAdi)
                .HasMaxLength(50)
                .HasColumnName("Takim_adi");
            entity.Property(e => e.AttigiGolSayisi).HasColumnName("Attigi_gol_sayisi");
            entity.Property(e => e.BeraberlikSayisi).HasColumnName("Beraberlik_sayisi");
            entity.Property(e => e.GalibiyetSayisi).HasColumnName("Galibiyet_sayisi");
            entity.Property(e => e.MaglubiyetSayisi).HasColumnName("Maglubiyet_sayisi");
            entity.Property(e => e.OynadigiMacSayisi).HasColumnName("Oynadigi_mac_sayisi");
            entity.Property(e => e.YedigiGolSayisi).HasColumnName("Yedigi_gol_sayisi");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
