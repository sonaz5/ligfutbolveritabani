﻿using System;
using System.Collections.Generic;

namespace LİGFUTBOL.Models;

public partial class _201819
{
    public string TakimAdi { get; set; } = null!;

    public byte OynadigiMacSayisi { get; set; }

    public byte GalibiyetSayisi { get; set; }

    public byte BeraberlikSayisi { get; set; }

    public byte MaglubiyetSayisi { get; set; }

    public byte AttigiGolSayisi { get; set; }

    public byte YedigiGolSayisi { get; set; }

    public short Averaj { get; set; }

    public byte Puan { get; set; }
}
